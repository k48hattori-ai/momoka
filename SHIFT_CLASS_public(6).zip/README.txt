SHIFT CLASS 公開版

内容:
- index.html : 公開用のSHIFT CLASSプロトタイプ

公開方法（Netlify Drop）:
1. Netlify Dropを開く
2. このフォルダ、ZIP、またはindex.htmlをアップロード
3. 発行された netlify.app のURLを友達に共有

注意:
- 現在はプロトタイプのため、データは各ブラウザのlocalStorageに保存されます。
- 先生と生徒を別端末でリアルタイム同期する本番版には、Firebase等のバックエンドが必要です。
- 実際のGoogleログインには接続していません。
