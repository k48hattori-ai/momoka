# SHIFT CLASS 公開用

このフォルダは GitHub Pages にそのまま公開できる構成です。

## ファイル
- `index.html` — 公開デモ本体
- `.nojekyll` — GitHub Pages で静的ファイルをそのまま配信するための空ファイル

## 公開手順
1. GitHub で新しいリポジトリを作成します（例: `shift-class`）。
2. `index.html` と `.nojekyll` をリポジトリ直下にアップロードしてコミットします。
3. `Settings` → `Pages` → `Build and deployment` → `Source` で `Deploy from a branch` を選びます。
4. `main` と `/(root)` を選択して保存します。
5. 公開された `https://ユーザー名.github.io/shift-class/` をLINEなどで共有します。

共有ボタンは、対応端末ではOSの共有画面を開き、使えない場合はURLコピーへ切り替わります。
LINE向け共有URLには `openExternalBrowser=1` が自動付与され、LINE内ブラウザではなく外部ブラウザで開きやすくしています。
